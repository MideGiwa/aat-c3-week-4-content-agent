# Content Ops Console — front-end scaffold

This is the custom front-end for the AI Content Research & Publishing Agent
(see `../DESIGN.md`, `../FRONTEND-SPEC.md`, and `../CONTENT-PIPELINE-SPEC.md`
for the full system design). It replaces the earlier n8n-forms idea with a
real app so form validation, guardrails, and the human-review flow can all
be handled in one place — and, as of 2026-09-16, the content-generation
pipeline itself (research through channel prep) runs here too, as regular
Next.js server code, instead of a separate n8n workflow calling a standalone
Python service. n8n's only remaining job in the whole system is the
scheduled publish runner (unchanged, lives in `../workflows/`).

It ships two flows, plus the pipeline that connects them:

- **Submit Request** (`/requests/new`) — the intake form. Submitting one
  runs the full pipeline (research → curation → planning → drafting →
  self-evaluation → revision → channel prep) before the request is even
  created — you land on a request that's already at `pending_human_review`
  with a draft, evaluation history, and per-channel copy ready to look at.
- **Review Dashboard** (`/board`, `/requests/[id]`) — the Kanban board and
  the per-request draft review screen (versions, evaluation, sources,
  channel copy for every priority channel including newsletter, activity
  trail, approve/reject/request-changes).

## Running it locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000 — it redirects to `/board`.

No external services are required to run it as-is: it starts in **mock
data mode** (see below), which is the default and is safe to leave on for
demoing or continued front-end work.

Useful scripts:

```bash
npm run build      # production build
npm run typecheck  # tsc --noEmit
npm run lint       # next lint
```

## Mock data mode

`NEXT_PUBLIC_USE_MOCK_DATA=true` (the default — see `.env.example`) makes
the whole app run against an in-memory store seeded from
`src/lib/mock/seed.ts`, instead of Supabase, Claude, Firecrawl, Tavily, and
Voyage. This exists so the UI, the validation rules, the pipeline, and the
trickier guardrails (see below) can all be exercised and demoed without any
live infrastructure or API keys.

The mock isn't a fake shell around empty screens — it re-implements the
*behavior* that matters, not just the shape of the data:

- **`src/lib/validation.ts`** is the one real copy of the intake validation
  rules (gibberish detection, URL format, file type/size, future-date
  scheduling). It's called from both the client form (instant feedback)
  and the mock webhook handler (the server-side re-check) — so client and
  server can never quietly drift apart here.
- **`src/lib/pipeline/`** (`generate.ts` + `run.ts`) is the actual content
  pipeline — research, curation, planning, drafting, self-evaluation,
  revision, and channel prep — running as deterministic, templated mock
  logic instead of real API calls (see `../CONTENT-PIPELINE-SPEC.md` for
  what each stage does and why). It's wired into intake (every new
  submission runs the full pipeline synchronously) and into review-action
  (approving promotes channel assets to `ready_to_publish`; requesting
  changes triggers an immediate targeted revision).
- **`src/lib/mock/webhooks.ts`** implements the three internal write
  contracts (`content-request`, `review-action`, `manage-attachment`)
  against the mock store, including two guards worth knowing about:
  the multi-reviewer race guard (a second reviewer's decision on an
  already-decided draft is refused with `already_decided`, reproducing what
  a Postgres `UNIQUE` constraint on `review_decisions.draft_id` guarantees
  in the real system) and the stale-draft guard (a decision aimed at a
  draft the pipeline has since superseded with a newer version is refused
  with `stale_draft` — added once automatic revisions made this a real
  possibility, not just a theoretical one).
- Attachments can only be edited/removed while a request is still
  `intake_complete` — once research has consumed them, `manage-attachment`
  refuses with `already_consumed_by_research`, matching DESIGN.md §14.
- The seed data (`src/lib/mock/seed.ts`) deliberately includes one request
  at every pipeline status, a multi-version draft with a revision history,
  a custom (non-default) rubric criterion, per-channel copy (including
  newsletter) at every stage where the pipeline would have generated it,
  and a request that failed research — so every screen state is reachable
  without manually creating test data. New submissions go through the live
  pipeline instead and land wherever it actually takes them.

The mock store is a `globalThis`-backed singleton (`src/lib/mock/store.ts`)
so it survives Next.js dev-mode hot reloads. It resets whenever the dev
server process restarts — there's no persistence across runs, by design.

## Going from mock to real

Every read goes through `src/lib/data.ts`, and every write goes through
`src/lib/webhookClient.ts`, which in turn calls `src/lib/mock/webhooks.ts`
(mock) or would call the real pipeline/Supabase (real). All of it branches
on `USE_MOCK_DATA` (`src/lib/config.ts`); the real-mode branches currently
throw `NotImplementedInRealModeError`. To cut over:

1. Set `NEXT_PUBLIC_USE_MOCK_DATA=false` and fill in the Supabase variables
   in `.env.local` (copy `.env.example`) plus API keys for Anthropic,
   Firecrawl, Tavily/Exa, and Voyage AI — the pipeline calls these directly
   now, there's no separate service to point at.
2. Apply the schema in `../DESIGN.md` §6 to a real Supabase project,
   including the RLS policies described in `../FRONTEND-SPEC.md` ("RLS
   policy shape") and the `review_decisions.draft_id` `UNIQUE` constraint —
   that constraint is the actual mechanism the mock's find-then-refuse
   check is standing in for, so it isn't optional.
3. Implement the real-mode branch of each function in `src/lib/data.ts`
   (a Supabase client call per function — the commented-out query in each
   one is the shape to build).
4. Implement the real-mode branch of each function in
   `src/lib/pipeline/generate.ts` — each one's doc comment says exactly
   which real API replaces its mock logic (Firecrawl/Tavily for research,
   Voyage for embeddings, Claude for planning/drafting/evaluation/revision/
   channel prep). `src/lib/pipeline/run.ts`'s orchestration doesn't need to
   change — it calls the same function signatures either way. Decide there
   whether this runs synchronously in the API route or as a background job
   (see `../CONTENT-PIPELINE-SPEC.md` "Real mode").
5. n8n keeps exactly one job in the real system: the publish runner
   (`../workflows/n8n-publish-workflow.json`), polling `publishing_queue`
   for rows this app has already written. Nothing here calls into n8n.
6. Nothing above the data-access/webhook-client/pipeline layer needs to
   change — no component or page imports Supabase, Anthropic, or any other
   API client directly.

## What isn't built yet

Carried over from `FRONTEND-SPEC.md` "not built yet": real authentication
(the app currently acts as a single hardcoded profile,
`MOCK_CURRENT_PROFILE_ID` in `src/lib/config.ts`), file upload to Supabase
Storage (the form captures a file's name/size for validation but doesn't
upload bytes anywhere in mock mode), and the rubric-criteria management
screen (custom criteria are readable/displayed but not yet editable from
the UI).
