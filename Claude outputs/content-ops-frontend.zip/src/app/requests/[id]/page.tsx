import Link from "next/link";
import { notFound } from "next/navigation";
import { getRequestDetail } from "@/lib/data";
import StatusBadge from "@/components/StatusBadge";
import DraftReviewPanel from "@/components/review/DraftReviewPanel";
import ChannelAssetsPanel from "@/components/review/ChannelAssetsPanel";
import SourceList from "@/components/review/SourceList";
import ActivityTrail from "@/components/review/ActivityTrail";

export const dynamic = "force-dynamic"; // always read the latest mock/live state

const CHANNEL_LABEL: Record<string, string> = {
  linkedin: "LinkedIn",
  x: "X",
  newsletter: "Newsletter",
};

export default async function RequestDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const detail = await getRequestDetail(params.id);
  if (!detail) notFound();

  const { request, submitter, reviewers, sources, drafts, evaluations, channelAssets, activity, decision } =
    detail;

  return (
    <div>
      <Link href="/board" className="text-xs text-accent-700 hover:underline">
        ← Back to board
      </Link>

      <div className="mt-2 mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">{request.idea_or_topic}</h1>
          <p className="text-sm text-slate-500 mt-1">{request.target_audience}</p>
        </div>
        <StatusBadge status={request.status} />
      </div>

      {request.status === "research_failed" && request.failure_reason && (
        <div className="mb-6 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          Research failed: {request.failure_reason.replace(/_/g, " ")}. This request stayed
          isolated — it did not affect any other request in the pipeline (DESIGN.md §15).
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <DraftReviewPanel
            requestId={request.id}
            drafts={drafts}
            evaluations={evaluations}
            sources={sources}
            latestDecision={decision}
          />

          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-2">Channel copy</h3>
            <ChannelAssetsPanel assets={channelAssets} />
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <h3 className="text-sm font-semibold text-slate-700 mb-2">Request details</h3>
            <dl className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <dt className="text-slate-400">Submitted by</dt>
                <dd className="text-slate-700">{submitter.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Reviewers</dt>
                <dd className="text-slate-700 text-right">
                  {reviewers.length > 0
                    ? reviewers.map((r) => r.name).join(", ")
                    : "None assigned"}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Tone</dt>
                <dd className="text-slate-700">{request.tone}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Channels</dt>
                <dd className="text-slate-700 text-right">
                  {request.priority_channels.map((c) => CHANNEL_LABEL[c] ?? c).join(", ")}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Publish timing</dt>
                <dd className="text-slate-700 text-right">
                  {request.publish_timing === "scheduled" && request.scheduled_for
                    ? new Date(request.scheduled_for).toLocaleString()
                    : "Immediately"}
                </dd>
              </div>
              {request.source_url && (
                <div className="flex justify-between gap-2">
                  <dt className="text-slate-400 shrink-0">Reference URL</dt>
                  <dd className="text-accent-700 text-right truncate">
                    <a href={request.source_url} target="_blank" rel="noreferrer" className="hover:underline">
                      {request.source_url}
                    </a>
                  </dd>
                </div>
              )}
            </dl>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <SourceList sources={sources} />
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <ActivityTrail entries={activity} />
          </div>
        </div>
      </div>
    </div>
  );
}
