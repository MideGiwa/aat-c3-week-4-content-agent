import { listProfiles } from "@/lib/data";
import { MOCK_CURRENT_PROFILE_ID } from "@/lib/config";
import NewRequestForm from "@/components/forms/NewRequestForm";

export const dynamic = "force-dynamic";

export default async function NewRequestPage() {
  const profiles = await listProfiles();

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-900">New content request</h1>
        <p className="text-sm text-slate-500">
          This goes straight into the pipeline — research and drafting start automatically once
          it's submitted.
        </p>
      </div>
      <NewRequestForm profiles={profiles} currentProfileId={MOCK_CURRENT_PROFILE_ID} />
    </div>
  );
}
