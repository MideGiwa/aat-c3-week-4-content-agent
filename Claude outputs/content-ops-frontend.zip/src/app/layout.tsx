import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";
import { USE_MOCK_DATA } from "@/lib/config";

export const metadata: Metadata = {
  title: "Content Ops Console",
  description: "AI Content Research & Publishing Agent — request and review console",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen flex flex-col">
          <header className="border-b border-slate-200 bg-white">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
              <Link href="/board" className="font-semibold text-slate-900">
                Content Ops Console
              </Link>
              <div className="flex items-center gap-4">
                {USE_MOCK_DATA && (
                  <span className="text-xs font-medium text-amber-700 bg-amber-100 px-2 py-1 rounded-full">
                    Mock data mode
                  </span>
                )}
                <Link
                  href="/requests/new"
                  className="text-sm font-medium bg-accent-600 text-white px-3 py-1.5 rounded-md hover:bg-accent-700"
                >
                  + New Request
                </Link>
              </div>
            </div>
          </header>
          <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
