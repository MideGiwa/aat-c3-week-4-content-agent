import { NextRequest, NextResponse } from "next/server";
import { submitReviewAction } from "@/lib/webhookClient";
import { MOCK_CURRENT_PROFILE_ID } from "@/lib/config";

// Stands in for n8n's POST /webhook/review-action (FRONTEND-SPEC.md "Flow
// 2"). Returns 409 (not 200/500) for either of two distinct conflict
// outcomes the UI is expected to show specifically, not treat as a generic
// failure: "already_decided" (lost the review_decisions race) and
// "stale_draft" (acted on a draft the pipeline has since superseded with a
// newer version — see the guard in handleReviewActionWebhook).
export async function POST(req: NextRequest) {
  const body = await req.json();

  const result = await submitReviewAction({
    request_id: body.request_id,
    draft_id: body.draft_id,
    channel_asset_id: body.channel_asset_id ?? null,
    action: body.action,
    reviewer_id: body.reviewer_id ?? MOCK_CURRENT_PROFILE_ID,
    notes: body.notes ?? null,
    selected_option_label: body.selected_option_label ?? null,
  });

  if (!result.ok) {
    const status = result.reason === "already_decided" || result.reason === "stale_draft" ? 409 : 404;
    return NextResponse.json(result, { status });
  }
  return NextResponse.json(result, { status: 200 });
}
