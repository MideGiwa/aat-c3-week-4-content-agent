import { NextRequest, NextResponse } from "next/server";
import { submitContentRequest } from "@/lib/webhookClient";
import { MOCK_CURRENT_PROFILE_ID } from "@/lib/config";

// This route is the Next.js server layer standing between the browser and
// n8n's real POST /webhook/content-request (INTAKE-AND-RESEARCH-SPEC.md
// §1). The browser calls THIS route, never n8n directly — see
// FRONTEND-SPEC.md "Security summary."
export async function POST(req: NextRequest) {
  const body = await req.json();

  const result = await submitContentRequest({
    idea_or_topic: body.idea_or_topic ?? "",
    target_audience: body.target_audience ?? "",
    source_url: body.source_url ?? "",
    tone: body.tone ?? "",
    priority_channels: body.priority_channels ?? [],
    publish_timing: body.publish_timing ?? "immediately",
    scheduled_for: body.scheduled_for ?? "",
    attachment_file_name: body.attachment_file_name,
    attachment_size_bytes: body.attachment_size_bytes,
    submitted_by: MOCK_CURRENT_PROFILE_ID,
    reviewer_ids: body.reviewer_ids ?? [],
  });

  if (!result.ok) {
    return NextResponse.json(result, { status: 422 });
  }
  return NextResponse.json(result, { status: 200 });
}
