// Server-side only. Called from the API routes in src/app/api/webhooks/*,
// never directly from client components — see FRONTEND-SPEC.md "Security
// summary": the browser never holds N8N_WEBHOOK_SECRET.

import { N8N_WEBHOOK_BASE_URL, N8N_WEBHOOK_SECRET, USE_MOCK_DATA } from "./config";
import {
  handleContentRequestWebhook,
  handleManageAttachmentWebhook,
  handleReviewActionWebhook,
  type ContentRequestWebhookResult,
  type ManageAttachmentInput,
  type ManageAttachmentResult,
  type ReviewActionInput,
  type ReviewActionWebhookResult,
} from "./mock/webhooks";
import type { NewRequestInput } from "./validation";

async function callRealWebhook<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${N8N_WEBHOOK_BASE_URL}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Webhook-Secret": N8N_WEBHOOK_SECRET,
    },
    body: JSON.stringify(body),
  });
  return res.json();
}

export async function submitContentRequest(
  input: NewRequestInput & { submitted_by: string; reviewer_ids: string[] }
): Promise<ContentRequestWebhookResult> {
  if (USE_MOCK_DATA) return handleContentRequestWebhook(input);
  return callRealWebhook<ContentRequestWebhookResult>("/content-request", input);
}

export async function submitReviewAction(
  input: ReviewActionInput
): Promise<ReviewActionWebhookResult> {
  if (USE_MOCK_DATA) return handleReviewActionWebhook(input);
  return callRealWebhook<ReviewActionWebhookResult>("/review-action", input);
}

export async function submitManageAttachment(
  input: ManageAttachmentInput
): Promise<ManageAttachmentResult> {
  if (USE_MOCK_DATA) return handleManageAttachmentWebhook(input);
  return callRealWebhook<ManageAttachmentResult>("/manage-attachment", input);
}
