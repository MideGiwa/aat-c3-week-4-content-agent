import { USE_MOCK_DATA } from "./config";
import { getStore } from "./mock/store";
import type { ContentRequest, Profile, RequestDetail } from "./types";

// The data-access layer. Every read the app needs goes through here so
// that swapping mock data for real Supabase later (FRONTEND-SPEC.md
// "Architecture") means rewriting the *inside* of these functions, not
// every place that calls them. Real-mode implementations are stubbed with
// the Supabase query they'd run, commented, rather than built blind against
// a schema no live project has applied yet.

export async function getProfile(id: string): Promise<Profile | null> {
  if (USE_MOCK_DATA) {
    return getStore().profiles.find((p) => p.id === id) ?? null;
  }
  throw new NotImplementedInRealModeError("getProfile");
  // Real mode:
  // const { data } = await supabaseServer.from("profiles").select("*").eq("id", id).single();
  // return data;
}

export async function listRequests(): Promise<ContentRequest[]> {
  if (USE_MOCK_DATA) {
    return [...getStore().requests].sort(
      (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    );
  }
  throw new NotImplementedInRealModeError("listRequests");
  // Real mode: RLS-scoped read — a content manager sees their own requests,
  // a reviewer sees anything in request_reviewers for their profile id,
  // an admin sees everything (FRONTEND-SPEC.md "RLS policy shape").
  // const { data } = await supabaseBrowser.from("requests").select("*");
  // return data ?? [];
}

export async function getRequestDetail(requestId: string): Promise<RequestDetail | null> {
  if (USE_MOCK_DATA) {
    const store = getStore();
    const request = store.requests.find((r) => r.id === requestId);
    if (!request) return null;

    const submitter = store.profiles.find((p) => p.id === request.submitted_by);
    if (!submitter) return null;

    const reviewers = store.profiles.filter((p) => request.reviewer_ids.includes(p.id));
    const sources = store.sources.filter((s) => s.request_id === requestId);
    const drafts = store.drafts
      .filter((d) => d.request_id === requestId)
      .sort((a, b) => a.version - b.version);
    const draftIds = new Set(drafts.map((d) => d.id));
    const evaluations = store.evaluations
      .filter((e) => draftIds.has(e.draft_id))
      .sort((a, b) => a.round - b.round);
    const channelAssets = store.channelAssets.filter((c) => c.request_id === requestId);
    const activity = store.activity
      .filter((a) => a.request_id === requestId)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

    const latestDraft = drafts[drafts.length - 1];
    const decision = latestDraft
      ? store.decisions.find((d) => d.draft_id === latestDraft.id) ?? null
      : null;

    return {
      request,
      submitter,
      reviewers,
      sources,
      drafts,
      evaluations,
      channelAssets,
      activity,
      decision,
    };
  }
  throw new NotImplementedInRealModeError("getRequestDetail");
  // Real mode: one Supabase call per related table (or a single RPC/view
  // that joins them), all scoped by the same RLS rules as listRequests().
}

export async function listProfiles(): Promise<Profile[]> {
  if (USE_MOCK_DATA) {
    return getStore().profiles;
  }
  throw new NotImplementedInRealModeError("listProfiles");
}

export class NotImplementedInRealModeError extends Error {
  constructor(fn: string) {
    super(
      `${fn}() has no real-mode implementation yet. This scaffold ships with mock data only — ` +
        `see README.md "Going from mock to real" for what to fill in (Supabase client + queries).`
    );
    this.name = "NotImplementedInRealModeError";
  }
}
