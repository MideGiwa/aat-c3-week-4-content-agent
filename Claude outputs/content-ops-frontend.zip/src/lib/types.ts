// Shared types mirroring DESIGN.md §6 (Data Model). Kept close to the
// Supabase schema on purpose — when this app moves off mock data, these
// types should need little to no change, only the data-access layer
// (src/lib/data.ts) does.

export type Channel = "linkedin" | "x" | "newsletter";

export type RequestStatus =
  | "intake_complete"
  | "research_failed"
  | "research_complete"
  | "drafting"
  | "pending_human_review"
  | "needs_manual_revision"
  | "rejected_by_human"
  | "approved"
  | "published";

/** The five Kanban columns. Several RequestStatus values collapse into one
 * column; see boardColumnForStatus() in src/lib/board.ts. */
export type BoardColumn =
  | "researching"
  | "drafting"
  | "in_review"
  | "approved"
  | "published";

export type FileType = "txt" | "pdf" | "spreadsheet" | "docx";
export type AttachmentStatus = "uploaded" | "processing" | "corrupt" | "removed";

export interface Profile {
  id: string;
  name: string;
  email: string;
  roles: Array<"content_manager" | "reviewer" | "admin">;
}

export interface RequestAttachment {
  id: string;
  request_id: string;
  file_type: FileType;
  file_name: string;
  status: AttachmentStatus;
  uploaded_at: string;
  removed_at: string | null;
}

export interface ContentRequest {
  id: string;
  idea_or_topic: string;
  target_audience: string;
  source_url: string | null;
  tone: string;
  priority_channels: Channel[];
  publish_timing: "immediately" | "scheduled";
  scheduled_for: string | null;
  status: RequestStatus;
  failure_reason: string | null;
  submitted_by: string; // profile id
  reviewer_ids: string[]; // profile ids (request_reviewers)
  created_at: string;
  updated_at: string;
}

export interface SourceRef {
  id: string;
  request_id: string;
  url: string;
  title: string;
  retrieved_at: string;
  selected: boolean;
  relevance_note: string | null;
}

export interface DraftSection {
  heading: string;
  body: string;
  cited_source_ids: string[];
}

export interface Draft {
  id: string;
  request_id: string;
  version: number;
  option_label: string;
  title: string;
  sections: DraftSection[];
  generated_by: "system_initial" | "system_revision" | "human_requested";
  created_at: string;
}

export interface RubricScore {
  criterion: string;
  scope: "default" | "custom";
  score: number; // 0-10
  notes: string;
}

export interface Evaluation {
  id: string;
  draft_id: string;
  round: number;
  status: "pass" | "revise" | "reject";
  scores: RubricScore[];
  unsupported_claims: string[];
  sections_needing_revision: string[];
  created_at: string;
}

export interface ChannelAsset {
  id: string;
  request_id: string;
  draft_id: string;
  channel: Channel;
  content: string;
  status: "draft" | "ready_to_publish" | "published" | "failed";
}

export type ActivityAction =
  | "submit_request"
  | "complete_research"
  | "select_option"
  | "evaluate_draft"
  | "regenerate_draft"
  | "prepare_channel_assets"
  | "approve"
  | "reject"
  | "request_changes"
  | "add_reviewer"
  | "remove_attachment";

export interface ActivityLogEntry {
  id: string;
  request_id: string;
  actor_type: "system" | "human";
  actor_id: string | null; // profile id, or null for system
  actor_name: string; // denormalized for display convenience in mock mode
  action: ActivityAction;
  target: string | null;
  notes: string | null;
  created_at: string;
}

/** A single row in review_decisions — the table with the UNIQUE constraint
 * (DESIGN.md §6) that makes "first decisive action wins" airtight rather
 * than an app-level check-then-act race. */
export interface ReviewDecision {
  id: string;
  draft_id: string;
  action: "approve" | "reject" | "request_changes";
  reviewer_id: string;
  notes: string | null;
  decided_at: string;
}

/** Everything the review screen needs for one request, joined together —
 * this is the shape src/lib/data.ts's getRequestDetail() returns. */
export interface RequestDetail {
  request: ContentRequest;
  submitter: Profile;
  reviewers: Profile[];
  sources: SourceRef[];
  drafts: Draft[]; // all versions, ordered
  evaluations: Evaluation[]; // all rounds, across all drafts
  channelAssets: ChannelAsset[];
  activity: ActivityLogEntry[];
  decision: ReviewDecision | null; // set once a reviewer has decided
}
