// Mock content-generation primitives for the automated pipeline (research →
// curation → planning → drafting → evaluation → revision → channel prep).
//
// This is the mock half of what CONTENT-PIPELINE-SPEC.md describes. Every
// function here is deterministic and template-based — no network calls, no
// Claude API, no Firecrawl/Tavily/Voyage — so the pipeline is runnable with
// zero API keys and produces the same output for the same input. Real mode
// replaces the *insides* of these functions with actual calls (see the
// "Going from mock to real" section of README.md and the real-mode notes
// inline below); nothing that calls into src/lib/pipeline/run.ts needs to
// change when that happens.

import type { ChannelAsset, Channel, ContentRequest, Draft, DraftSection, Evaluation, RubricScore, SourceRef } from "../types";
import { nextId } from "../mock/store";

const DEFAULT_RUBRIC_CRITERIA = [
  "Topic Relevance",
  "Source Grounding",
  "Factual Consistency",
  "Audience Fit",
  "Tone",
  "SEO Fit",
  "Channel Fit",
  "Clarity",
  "Completeness",
] as const;

function titleCase(input: string): string {
  return input
    .trim()
    .replace(/\s+/g, " ")
    .split(" ")
    .map((word) => (word.length > 3 ? word[0].toUpperCase() + word.slice(1) : word))
    .join(" ");
}

/** Research + Source Retrieval. Real mode: Firecrawl (scrape request.source_url
 * if provided) + Tavily/Exa (search on idea_or_topic), then Voyage AI
 * embeddings for the chunked results (INTAKE-AND-RESEARCH-SPEC.md §2 —
 * superseded in structure, not in these parameters, by
 * CONTENT-PIPELINE-SPEC.md). Mock mode fabricates 3–4 plausible-looking
 * sources instead, with the last one deliberately marked irrelevant so
 * curation below has something real to reject. */
export function generateSources(request: ContentRequest): SourceRef[] {
  const now = new Date().toISOString();
  const topic = request.idea_or_topic.trim();
  const sources: SourceRef[] = [];

  if (request.source_url) {
    sources.push({
      id: nextId("src"),
      request_id: request.id,
      url: request.source_url,
      title: `Reference material: ${titleCase(topic)}`,
      retrieved_at: now,
      selected: true,
      relevance_note: "Provided directly with the request — treated as a primary source.",
    });
  }

  sources.push(
    {
      id: nextId("src"),
      request_id: request.id,
      url: `https://example-research.com/articles/${slugify(topic)}`,
      title: `Industry brief: ${titleCase(topic)}`,
      retrieved_at: now,
      selected: true,
      relevance_note: `Directly on-topic for "${topic}" — used for the core argument.`,
    },
    {
      id: nextId("src"),
      request_id: request.id,
      url: `https://example-news.com/${slugify(request.target_audience)}-perspective`,
      title: `${titleCase(request.target_audience)}: what's changing`,
      retrieved_at: now,
      selected: true,
      relevance_note: `Grounds the piece in what ${request.target_audience.toLowerCase()} actually care about.`,
    },
    {
      id: nextId("src"),
      request_id: request.id,
      url: "https://example.com/unrelated-listicle",
      title: "Unrelated general-interest listicle",
      retrieved_at: now,
      selected: false,
      relevance_note: "Below the relevance floor during source curation — not specific to this topic.",
    }
  );

  return sources;
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 40);
}

/** Planning. Real mode: a Claude call proposing 2+ angles/titles for the
 * same brief (CONTENT-PIPELINE-SPEC.md §3). Mock mode proposes two
 * templated angles and picks one with a simple, explainable heuristic
 * (recorded in the activity log as a "select_option" entry) rather than
 * fully drafting and evaluating both — see CONTENT-PIPELINE-SPEC.md's
 * "Scope decision" note for why. */
export function planTitleOptions(request: ContentRequest): { options: [string, string]; chosenIndex: 0 | 1; reason: string } {
  const topic = titleCase(request.idea_or_topic.trim());
  const optionA = topic.endsWith("?") ? topic : `${topic}: What ${titleCase(request.target_audience)} Need to Know`;
  const optionB = topic.endsWith("?") ? `Is It Time to Rethink ${topic.replace(/\?$/, "")}?` : `${topic}?`;

  // Heuristic: prefer the direct, non-question framing for a professional/
  // authoritative tone (clearer, more citable), and the question framing for
  // a conversational/playful tone (more inviting). This is a stand-in for
  // what would be a Claude judgment call in real mode.
  const preferDirect = request.tone === "professional" || request.tone === "authoritative";
  const chosenIndex: 0 | 1 = preferDirect ? 0 : 1;
  const reason = preferDirect
    ? "Direct framing reads clearer for a professional/authoritative tone and states the payoff up front."
    : "Question framing is more inviting for a conversational/playful tone and matches how the audience would search for this.";

  return { options: [optionA, optionB], chosenIndex, reason };
}

/** Drafting. Real mode: a Claude call producing structured sections from
 * the plan + curated sources (CONTENT-PIPELINE-SPEC.md §4). Mock mode
 * templates 3 sections from the request and selected sources.
 *
 * Deliberate mock behavior: the last section is generated WITHOUT a cited
 * source on the first pass (version 1) — representing a realistic
 * first-draft gap — so the evaluation step below has a real, specific
 * reason to flag it and the revision step has something concrete to fix.
 * This is what makes "revise weak drafts" demonstrable end-to-end instead
 * of every draft trivially passing round 1. */
export function generateDraft(
  request: ContentRequest,
  sources: SourceRef[],
  title: string,
  version: number,
  generatedBy: Draft["generated_by"]
): Draft {
  const selected = sources.filter((s) => s.selected);
  const primary = selected[0];
  const secondary = selected[1] ?? primary;

  const sections: DraftSection[] = [
    {
      heading: "Why this matters now",
      body: `For ${request.target_audience.toLowerCase()}, "${request.idea_or_topic.trim()}" isn't a hypothetical — it's showing up in day-to-day decisions already. This piece lays out what's actually changing and why it's worth paying attention to.`,
      cited_source_ids: primary ? [primary.id] : [],
    },
    {
      heading: "What the research shows",
      body: `Looking at the available material, the pattern is consistent: this is moving faster than most ${request.target_audience.toLowerCase()} expect, and the organizations paying attention early are adapting with less disruption.`,
      cited_source_ids: secondary ? [secondary.id] : [],
    },
    {
      heading: "What to do next",
      body: `The practical takeaway is straightforward: treat this as a near-term priority, not a someday item. Start with a small, low-risk pilot, measure what actually changes, and expand from there.`,
      cited_source_ids: [], // intentionally uncited on the first pass — see function doc
    },
  ];

  return {
    id: nextId("draft"),
    request_id: request.id,
    version,
    option_label: "A",
    title,
    sections,
    generated_by: generatedBy,
    created_at: new Date().toISOString(),
  };
}

/** Self-Evaluation against the rubric. Real mode: a Claude call against the
 * default 9-criterion rubric plus any custom criteria configured for this
 * request's channel/content type (DESIGN.md §13), returning a schema that's
 * validated and — per the "never fail open" principle — a schema failure
 * is surfaced as an error, never silently treated as a pass
 * (CONTENT-PIPELINE-SPEC.md §5 / the retired LLM-SERVICE-SPEC.md §4).
 *
 * Mock mode scores deterministically from the draft's own shape: a section
 * with no cited source measurably lowers Source Grounding and gets flagged,
 * which is what drives the revision step below — not a random number. */
export function evaluateDraft(draft: Draft, round: number): Evaluation {
  const uncitedSections = draft.sections.filter((s) => s.cited_source_ids.length === 0);
  const groundingScore = uncitedSections.length === 0 ? 9 : Math.max(4, 9 - uncitedSections.length * 3);

  const scores: RubricScore[] = DEFAULT_RUBRIC_CRITERIA.map((criterion) => {
    if (criterion === "Source Grounding") {
      return {
        criterion,
        scope: "default",
        score: groundingScore,
        notes:
          uncitedSections.length === 0
            ? "Every section attributes its claim to a specific source."
            : `${uncitedSections.length} section(s) assert a claim without a cited source.`,
      };
    }
    if (criterion === "Channel Fit") {
      return { criterion, scope: "default", score: 8, notes: "N/A at article stage — scored per channel after drafting." };
    }
    return { criterion, scope: "default", score: 8, notes: "" };
  });

  const unsupportedClaims = uncitedSections.map(
    (s) => `"${s.heading}" makes a claim ("${s.body.slice(0, 60)}...") without a cited source.`
  );

  const status: Evaluation["status"] = groundingScore < 7 ? "revise" : "pass";

  return {
    id: nextId("eval"),
    draft_id: draft.id,
    round,
    status,
    scores,
    unsupported_claims: unsupportedClaims,
    sections_needing_revision: uncitedSections.map((s) => s.heading),
    created_at: new Date().toISOString(),
  };
}

/** Revision. Real mode: a Claude call given the specific evaluation
 * feedback (or a human reviewer's notes) and asked to fix only what was
 * flagged, not regenerate from scratch (CONTENT-PIPELINE-SPEC.md §6).
 * Mock mode: for every section the evaluation flagged as uncited, attaches
 * the best remaining selected source and appends an explicit attribution
 * phrase to the body — the same fix pattern already shown in the seed data
 * (draft-1 → draft-2). If reviewer notes are provided (a human's
 * request_changes), they're appended as an addressed note on the first
 * flagged section so the "what changed and why" is visible in the diff,
 * not just in the activity log. */
export function reviseDraft(
  previous: Draft,
  sources: SourceRef[],
  evaluation: Evaluation,
  generatedBy: Draft["generated_by"],
  reviewerNotes?: string | null
): Draft {
  const selected = sources.filter((s) => s.selected);
  const flaggedHeadings = new Set(evaluation.sections_needing_revision);

  const sections: DraftSection[] = previous.sections.map((section, idx) => {
    if (!flaggedHeadings.has(section.heading)) return section;

    const alreadyCited = new Set(previous.sections.flatMap((s) => s.cited_source_ids));
    const fix = selected.find((s) => !alreadyCited.has(s.id)) ?? selected[0];
    const attribution = fix ? ` This is backed directly by ${fix.title}.` : "";
    const reviewerNote = reviewerNotes && idx === 0 ? ` (Addressed reviewer note: "${reviewerNotes}")` : "";

    return {
      ...section,
      body: `${section.body}${attribution}${reviewerNote}`,
      cited_source_ids: fix ? [...section.cited_source_ids, fix.id] : section.cited_source_ids,
    };
  });

  return {
    id: nextId("draft"),
    request_id: previous.request_id,
    version: previous.version + 1,
    option_label: previous.option_label,
    title: previous.title,
    sections,
    generated_by: generatedBy,
    created_at: new Date().toISOString(),
  };
}

const CHANNEL_CHAR_LIMITS: Record<Channel, number | null> = {
  linkedin: 3000,
  x: 280,
  newsletter: null,
};

/** Channel-specific adaptation ("prepare the selected content for LinkedIn,
 * X, and an email newsletter"). Real mode: a Claude call per channel using
 * that channel's formatting rules (length limits, hashtag/thread
 * conventions, subject-line conventions for the newsletter). Mock mode
 * templates each from the final draft's title and first section.
 *
 * Every requested channel gets an asset here, including newsletter — it's
 * generated and reviewable like any other channel, it just isn't picked up
 * by the n8n publish runner yet (DESIGN.md §11 "Scope note"; see
 * ChannelAssetsPanel in the review UI). Assets are created in "draft"
 * status — a human approving the article promotes them to
 * "ready_to_publish" (src/lib/pipeline/run.ts), which is what makes them
 * eligible for the publish queue. */
export function prepareChannelAssets(request: ContentRequest, draft: Draft): ChannelAsset[] {
  const hook = draft.sections[0]?.body.slice(0, 140).trim() ?? draft.title;

  return request.priority_channels.map((channel) => {
    const limit = CHANNEL_CHAR_LIMITS[channel];
    let content: string;

    if (channel === "linkedin") {
      content = `${draft.title}\n\n${hook}\n\nWhat's your take? Drop a comment below.`;
    } else if (channel === "x") {
      const body = `${draft.title} — ${hook}`;
      content = limit && body.length > limit ? `${body.slice(0, limit - 1)}…` : body;
    } else {
      // newsletter
      content = `Subject: ${draft.title}\n\nHi there,\n\n${draft.sections.map((s) => `${s.heading}\n${s.body}`).join("\n\n")}\n\n— Sent via the Content Ops pipeline (draft, not yet distributed — see DESIGN.md §11).`;
    }

    return {
      id: nextId("ca"),
      request_id: request.id,
      draft_id: draft.id,
      channel,
      content,
      status: "draft",
    };
  });
}
