// Pipeline orchestration — the automated stretch between "request submitted"
// and "ready for a human to look at": research, source curation, planning,
// draft generation, self-evaluation, revision, and channel-specific prep.
//
// This used to be split across an n8n workflow and a standalone Python/
// FastAPI "LLM service" (LLM-SERVICE-SPEC.md). Both are superseded — see
// CONTENT-PIPELINE-SPEC.md — in favor of running the whole thing as Next.js
// server code, called synchronously from the intake and review-action
// webhook handlers (src/lib/mock/webhooks.ts). In mock mode this is cheap
// enough to run inline (no real network calls); real mode would run the
// same steps against real APIs, most likely from a background job rather
// than blocking the HTTP response — see the README "Going from mock to
// real" section.

import type { ContentRequest, Draft } from "../types";
import type { MockStore } from "../mock/store";
import { nextId } from "../mock/store";
import {
  evaluateDraft,
  generateDraft,
  generateSources,
  planTitleOptions,
  prepareChannelAssets,
  reviseDraft,
} from "./generate";

const MAX_AUTO_REVISION_ROUNDS = 1; // matches the seed example (draft-1 → draft-2, one auto-revision)

type PipelineActivityAction =
  | "complete_research"
  | "select_option"
  | "evaluate_draft"
  | "regenerate_draft"
  | "prepare_channel_assets";

function logActivity(
  store: MockStore,
  requestId: string,
  action: PipelineActivityAction,
  notes: string | null,
  target: string | null = null
) {
  store.activity.push({
    id: nextId("act"),
    request_id: requestId,
    actor_type: "system",
    actor_id: null,
    actor_name: "System",
    action,
    target,
    notes,
    created_at: new Date().toISOString(),
  });
}

/** Runs the full automated pipeline for a freshly-submitted request, taking
 * it from `intake_complete` to `pending_human_review` (mock mode always
 * succeeds at research — see generate.ts's module doc for why a research
 * failure isn't simulated here; EDGE-CASES-AND-GUARDRAILS.md covers that
 * failure path for the real system). Mutates the store in place. */
export function runInitialPipeline(request: ContentRequest, store: MockStore): void {
  const sources = generateSources(request);
  store.sources.push(...sources);
  logActivity(
    store,
    request.id,
    "complete_research",
    `Retrieved ${sources.length} source(s); ${sources.filter((s) => s.selected).length} selected as relevant, ${sources.filter((s) => !s.selected).length} rejected below the relevance floor.`
  );

  const { options, chosenIndex, reason } = planTitleOptions(request);
  const chosenTitle = options[chosenIndex];
  logActivity(
    store,
    request.id,
    "select_option",
    `Considered 2 title/angle options ("${options[0]}" vs. "${options[1]}"); selected "${chosenTitle}" — ${reason}`
  );

  let draft: Draft = generateDraft(request, sources, chosenTitle, 1, "system_initial");
  store.drafts.push(draft);

  let evaluation = evaluateDraft(draft, 1);
  store.evaluations.push(evaluation);
  logActivity(
    store,
    request.id,
    "evaluate_draft",
    `Round 1: ${evaluation.status}.${evaluation.unsupported_claims.length > 0 ? ` Flagged: ${evaluation.unsupported_claims.join(" ")}` : ""}`,
    draft.id
  );

  let round = 1;
  while (evaluation.status !== "pass" && round <= MAX_AUTO_REVISION_ROUNDS) {
    const revised = reviseDraft(draft, sources, evaluation, "system_revision");
    store.drafts.push(revised);
    logActivity(
      store,
      request.id,
      "regenerate_draft",
      `Automatic revision after round ${round} evaluation flagged: ${evaluation.sections_needing_revision.join(", ")}.`,
      revised.id
    );

    round += 1;
    draft = revised;
    evaluation = evaluateDraft(draft, round);
    store.evaluations.push(evaluation);
    logActivity(
      store,
      request.id,
      "evaluate_draft",
      `Round ${round}: ${evaluation.status}.`,
      draft.id
    );
  }

  const channelAssets = prepareChannelAssets(request, draft);
  store.channelAssets.push(...channelAssets);
  logActivity(
    store,
    request.id,
    "prepare_channel_assets",
    `Prepared copy for: ${channelAssets.map((c) => c.channel).join(", ")}. Newsletter is generated here but not auto-published — see DESIGN.md §11.`
  );

  request.status = "pending_human_review";
  request.updated_at = new Date().toISOString();
}

/** Runs a targeted revision after a reviewer requests changes — reuses the
 * same revise/evaluate/re-prepare-channel-copy steps as the automatic
 * mid-pipeline revision above, but seeded with the reviewer's own notes
 * rather than the evaluator's. Old channel assets for this request are
 * superseded (removed) since they were built from the now-outdated draft.
 * Sets the request straight back to `pending_human_review` with the new
 * version ready — see CONTENT-PIPELINE-SPEC.md §7 for why this resolves
 * synchronously instead of leaving the request sitting at
 * `needs_manual_revision` (that status still exists and is shown in the UI
 * for however briefly it's true, and is what a slower/real-mode revision
 * pass would actually rest at). */
export function runRevisionPipeline(
  request: ContentRequest,
  latestDraft: Draft,
  reviewerNotes: string | null,
  store: MockStore
): void {
  const sources = store.sources.filter((s) => s.request_id === request.id);
  const priorEvaluations = store.evaluations
    .filter((e) => e.draft_id === latestDraft.id)
    .sort((a, b) => b.round - a.round);
  const latestEvaluation = priorEvaluations[0] ?? evaluateDraft(latestDraft, 1);
  const maxRound = Math.max(0, ...store.evaluations.filter((e) => e.draft_id === latestDraft.id).map((e) => e.round));

  // If the AI evaluation had nothing flagged (a human is requesting changes
  // for reasons the rubric didn't catch), still revise something concrete:
  // treat the first section as the one to touch so the reviewer's note is
  // visibly addressed rather than silently ignored.
  const evaluationForRevision =
    latestEvaluation.sections_needing_revision.length > 0
      ? latestEvaluation
      : { ...latestEvaluation, sections_needing_revision: [latestDraft.sections[0]?.heading].filter(Boolean) as string[] };

  const revised = reviseDraft(latestDraft, sources, evaluationForRevision, "human_requested", reviewerNotes);
  store.drafts.push(revised);
  logActivity(
    store,
    request.id,
    "regenerate_draft",
    `Regenerated following reviewer-requested changes${reviewerNotes ? `: "${reviewerNotes}"` : "."}`,
    revised.id
  );

  const newEvaluation = evaluateDraft(revised, maxRound + 1);
  store.evaluations.push(newEvaluation);
  logActivity(store, request.id, "evaluate_draft", `Round ${newEvaluation.round}: ${newEvaluation.status}.`, revised.id);

  // Old channel copy was built from the superseded draft — drop it rather
  // than leave stale per-channel content sitting next to the new version.
  store.channelAssets = store.channelAssets.filter((c) => c.request_id !== request.id);
  const channelAssets = prepareChannelAssets(request, revised);
  store.channelAssets.push(...channelAssets);
  logActivity(
    store,
    request.id,
    "prepare_channel_assets",
    `Re-prepared copy for: ${channelAssets.map((c) => c.channel).join(", ")}.`
  );

  request.status = "pending_human_review";
  request.updated_at = new Date().toISOString();
}

/** Promotes this request's channel-specific copy from "draft" to
 * "ready_to_publish" once a human approves the article — this is what
 * makes LinkedIn/X rows eligible for the n8n publish runner's query
 * (n8n-publish-workflow.json polls for `status = 'ready_to_publish'`).
 * Newsletter rows are promoted the same way for consistency (they're just
 * as "ready" as the others) even though nothing currently consumes them —
 * see DESIGN.md §11 "Scope note." */
export function promoteChannelAssetsToReadyToPublish(requestId: string, draftId: string, store: MockStore): void {
  for (const asset of store.channelAssets) {
    if (asset.request_id === requestId && asset.draft_id === draftId && asset.status === "draft") {
      asset.status = "ready_to_publish";
    }
  }
}
