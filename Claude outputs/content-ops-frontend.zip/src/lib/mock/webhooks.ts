// Stand-ins for the three n8n webhooks in FRONTEND-SPEC.md / n8n-publish-workflow
// sibling docs: content-request, review-action, manage-attachment. Each
// function here does what the real n8n workflow is specified to do —
// including the parts that matter most for correctness — against the mock
// store instead of Supabase. When real mode is wired up, these are
// replaced by actual HTTP calls to N8N_WEBHOOK_BASE_URL (see
// src/lib/webhookClient.ts); the *shapes* below are the real contract.

import { getStore, nextId } from "./store";
import { validateNewRequest, type NewRequestInput } from "../validation";
import type { Channel, ContentRequest } from "../types";
import { promoteChannelAssetsToReadyToPublish, runInitialPipeline, runRevisionPipeline } from "../pipeline/run";

export interface ContentRequestWebhookResult {
  ok: boolean;
  request_id?: string;
  status?: ContentRequest["status"];
  errors?: { field: string; message: string }[];
}

export function handleContentRequestWebhook(
  input: NewRequestInput & { submitted_by: string; reviewer_ids: string[] }
): ContentRequestWebhookResult {
  // This is the actual gate — re-validated here exactly as n8n would,
  // regardless of what the browser's form already checked.
  // See INTAKE-AND-RESEARCH-SPEC.md §1, "why re-validate server-side."
  const errors = validateNewRequest(input);
  if (errors.length > 0) {
    return { ok: false, errors };
  }

  const store = getStore();
  const now = new Date().toISOString();
  const requestId = nextId("req");

  const newRequest: ContentRequest = {
    id: requestId,
    idea_or_topic: input.idea_or_topic.trim(),
    target_audience: input.target_audience.trim(),
    source_url: input.source_url || null,
    tone: input.tone || "professional",
    priority_channels: (input.priority_channels as Channel[]) ?? ["linkedin", "x", "newsletter"],
    publish_timing: input.publish_timing,
    scheduled_for: input.publish_timing === "scheduled" ? input.scheduled_for : null,
    status: "intake_complete",
    failure_reason: null,
    submitted_by: input.submitted_by,
    reviewer_ids: input.reviewer_ids,
    created_at: now,
    updated_at: now,
  };
  store.requests.push(newRequest);

  store.activity.push({
    id: nextId("act"),
    request_id: requestId,
    actor_type: "human",
    actor_id: input.submitted_by,
    actor_name: store.profiles.find((p) => p.id === input.submitted_by)?.name ?? "Unknown",
    action: "submit_request",
    target: null,
    notes: null,
    created_at: now,
  });

  // Research & Retrieval through Channel Prep now run right here, as
  // regular Next.js server code (CONTENT-PIPELINE-SPEC.md — this replaces
  // the earlier plan to hand off to n8n / a standalone LLM service). It's
  // cheap enough in mock mode to run synchronously before this function
  // returns, so by the time the request is created it's already sitting at
  // pending_human_review with a draft, an evaluation, and channel copy
  // ready — not stuck at intake_complete waiting on a stage that hasn't
  // run yet.
  runInitialPipeline(newRequest, store);

  return { ok: true, request_id: requestId, status: newRequest.status };
}

export interface ReviewActionInput {
  request_id: string;
  draft_id: string;
  channel_asset_id?: string | null;
  action: "approve" | "reject" | "request_changes" | "select_option";
  reviewer_id: string;
  notes?: string | null;
  selected_option_label?: string | null;
}

export type ReviewActionWebhookResult =
  | { ok: true; new_status: ContentRequest["status"] }
  | { ok: false; reason: "already_decided"; decided_by: string; decided_action: string }
  | { ok: false; reason: "stale_draft"; current_draft_id: string | null }
  | { ok: false; reason: "not_found" };

export function handleReviewActionWebhook(
  input: ReviewActionInput
): ReviewActionWebhookResult {
  const store = getStore();
  const request = store.requests.find((r) => r.id === input.request_id);
  if (!request) return { ok: false, reason: "not_found" };

  // Guards against acting on a superseded draft — e.g. a browser tab left
  // open on an old version, or a replayed/retried request arriving after an
  // automatic revision has already produced a newer one. The UI only ever
  // renders review actions against the current latest draft
  // (DraftReviewPanel), but nothing stopped a direct call from targeting an
  // older draft_id and silently moving the request to approved/rejected
  // against content that's no longer what a human would see. "Gate, don't
  // guess" applies here the same way it does to the already-decided race
  // below — check explicitly rather than assume the caller sent the right
  // id.
  const requestDrafts = store.drafts.filter((d) => d.request_id === request.id);
  const currentDraft = requestDrafts.reduce<(typeof requestDrafts)[number] | null>(
    (max, d) => (!max || d.version > max.version ? d : max),
    null
  );
  if (input.action !== "select_option" && currentDraft && currentDraft.id !== input.draft_id) {
    return { ok: false, reason: "stale_draft", current_draft_id: currentDraft.id };
  }

  // This is the part worth getting right: a real UNIQUE constraint on
  // review_decisions.draft_id means two reviewers can never both
  // successfully record a decision on the same draft, no matter how close
  // together their clicks land. The mock store can't lean on an actual
  // Postgres constraint, so it reproduces the same guarantee with a
  // find-then-refuse check performed as a single synchronous step (Node is
  // single-threaded per request in dev, so this is race-safe here the same
  // way the real UNIQUE constraint is race-safe under concurrent
  // transactions — the point is "only the first decision is ever
  // recorded," however it's enforced).
  const existing = store.decisions.find((d) => d.draft_id === input.draft_id);
  if (existing) {
    const decidedBy = store.profiles.find((p) => p.id === existing.reviewer_id)?.name ?? "another reviewer";
    return { ok: false, reason: "already_decided", decided_by: decidedBy, decided_action: existing.action };
  }

  const now = new Date().toISOString();
  const reviewer = store.profiles.find((p) => p.id === input.reviewer_id);

  if (input.action === "approve" || input.action === "reject" || input.action === "request_changes") {
    store.decisions.push({
      id: nextId("dec"),
      draft_id: input.draft_id,
      action: input.action,
      reviewer_id: input.reviewer_id,
      notes: input.notes ?? null,
      decided_at: now,
    });
  }

  let newStatus: ContentRequest["status"] = request.status;
  if (input.action === "approve") newStatus = "approved";
  else if (input.action === "reject") newStatus = "rejected_by_human";
  else if (input.action === "request_changes") newStatus = "needs_manual_revision";
  else if (input.action === "select_option") newStatus = request.status; // unchanged; just records a choice

  request.status = newStatus;
  request.updated_at = now;

  store.activity.push({
    id: nextId("act"),
    request_id: input.request_id,
    actor_type: "human",
    actor_id: input.reviewer_id,
    actor_name: reviewer?.name ?? "Unknown reviewer",
    action: input.action,
    target: input.draft_id,
    notes: input.notes ?? null,
    created_at: now,
  });

  // Downstream pipeline reactions to the decision — same module the intake
  // webhook uses (CONTENT-PIPELINE-SPEC.md §7).
  if (input.action === "approve") {
    // Makes this draft's channel copy eligible for the n8n publish runner.
    promoteChannelAssetsToReadyToPublish(input.request_id, input.draft_id, store);
  } else if (input.action === "request_changes") {
    const draft = store.drafts.find((d) => d.id === input.draft_id);
    if (draft) {
      // Resolves synchronously back to pending_human_review with a new
      // version ready — see runRevisionPipeline's doc comment for why.
      runRevisionPipeline(request, draft, input.notes ?? null, store);
      newStatus = request.status;
    }
  }

  return { ok: true, new_status: newStatus };
}

export interface ManageAttachmentInput {
  request_id: string;
  attachment_id: string;
  action: "remove" | "replace";
  new_storage_path?: string;
}

export type ManageAttachmentResult =
  | { ok: true }
  | { ok: false; reason: "already_consumed_by_research" | "not_found" };

export function handleManageAttachmentWebhook(
  input: ManageAttachmentInput
): ManageAttachmentResult {
  const store = getStore();
  const request = store.requests.find((r) => r.id === input.request_id);
  const attachment = store.attachments.find((a) => a.id === input.attachment_id);
  if (!request || !attachment) return { ok: false, reason: "not_found" };

  // DESIGN.md §14: editable/removable only before Research & Retrieval has
  // actually consumed it. "intake_complete" is the only status where that's
  // still true for this request.
  if (request.status !== "intake_complete") {
    return { ok: false, reason: "already_consumed_by_research" };
  }

  if (input.action === "remove") {
    attachment.status = "removed";
    attachment.removed_at = new Date().toISOString();
  }

  store.activity.push({
    id: nextId("act"),
    request_id: input.request_id,
    actor_type: "human",
    actor_id: request.submitted_by,
    actor_name: store.profiles.find((p) => p.id === request.submitted_by)?.name ?? "Unknown",
    action: "remove_attachment",
    target: input.attachment_id,
    notes: null,
    created_at: new Date().toISOString(),
  });

  return { ok: true };
}
