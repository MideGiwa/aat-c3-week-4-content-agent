export const USE_MOCK_DATA =
  process.env.NEXT_PUBLIC_USE_MOCK_DATA !== "false";

export const N8N_WEBHOOK_BASE_URL = process.env.N8N_WEBHOOK_BASE_URL ?? "";
export const N8N_WEBHOOK_SECRET = process.env.N8N_WEBHOOK_SECRET ?? "";

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
export const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

// Mirrors the "current user" that Supabase Auth would otherwise provide.
// In mock mode there's no real auth session, so the whole app acts as this
// one profile — a content manager who is also a reviewer, so both flows
// are reachable without needing to model multiple logged-in users yet.
export const MOCK_CURRENT_PROFILE_ID = "profile-mide";
