import Link from "next/link";
import type { ContentRequest } from "@/lib/types";
import StatusBadge from "../StatusBadge";
import { isFailureStatus } from "@/lib/board";

const CHANNEL_ICON: Record<string, string> = {
  linkedin: "in",
  x: "𝕏",
  newsletter: "✉",
};

export default function RequestCard({ request }: { request: ContentRequest }) {
  const needsAttention = isFailureStatus(request.status);

  return (
    <Link
      href={`/requests/${request.id}`}
      className={`block rounded-lg border bg-white p-3 shadow-sm hover:shadow-md transition-shadow ${
        needsAttention ? "border-red-300" : "border-slate-200"
      }`}
    >
      <p className="text-sm font-medium text-slate-900 line-clamp-2">{request.idea_or_topic}</p>
      <p className="mt-1 text-xs text-slate-500 line-clamp-1">{request.target_audience}</p>

      <div className="mt-2 flex items-center justify-between">
        <StatusBadge status={request.status} />
        <div className="flex items-center gap-1 text-slate-400" aria-label="Priority channels">
          {request.priority_channels.map((c) => (
            <span key={c} className="text-xs" title={c}>
              {CHANNEL_ICON[c] ?? c}
            </span>
          ))}
        </div>
      </div>

      {request.publish_timing === "scheduled" && request.scheduled_for && (
        <p className="mt-2 text-xs text-slate-400">
          Scheduled {new Date(request.scheduled_for).toLocaleString()}
        </p>
      )}

      {needsAttention && request.failure_reason && (
        <p className="mt-2 text-xs text-red-600">{request.failure_reason.replace(/_/g, " ")}</p>
      )}
    </Link>
  );
}
