"use client";

// Submit Request flow (FRONTEND-SPEC.md "Flow 1"). Validates client-side
// with the exact same rules the server re-checks (src/lib/validation.ts),
// purely for instant feedback — the POST below is what actually decides
// whether the request is created, since client-side checks can always be
// bypassed or skipped by a slow/flaky network.

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Channel, Profile } from "@/lib/types";
import { validateNewRequest, type FieldError, type NewRequestInput } from "@/lib/validation";

const CHANNELS: { value: Channel; label: string }[] = [
  { value: "linkedin", label: "LinkedIn" },
  { value: "x", label: "X" },
  { value: "newsletter", label: "Newsletter" },
];

export default function NewRequestForm({
  profiles,
  currentProfileId,
}: {
  profiles: Profile[];
  currentProfileId: string;
}) {
  const router = useRouter();

  const [ideaOrTopic, setIdeaOrTopic] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [sourceUrl, setSourceUrl] = useState("");
  const [tone, setTone] = useState("professional");
  const [channels, setChannels] = useState<Channel[]>(["linkedin", "x"]);
  const [publishTiming, setPublishTiming] = useState<"immediately" | "scheduled">("immediately");
  const [scheduledFor, setScheduledFor] = useState("");
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const [reviewerIds, setReviewerIds] = useState<string[]>([]);

  const [errors, setErrors] = useState<FieldError[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const reviewerCandidates = profiles.filter(
    (p) => p.id !== currentProfileId && p.roles.includes("reviewer")
  );

  function errorFor(field: string): string | undefined {
    return errors.find((e) => e.field === field)?.message;
  }

  function toggleChannel(channel: Channel) {
    setChannels((prev) =>
      prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel]
    );
  }

  function toggleReviewer(id: string) {
    setReviewerIds((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitError(null);

    const input: NewRequestInput = {
      idea_or_topic: ideaOrTopic,
      target_audience: targetAudience,
      source_url: sourceUrl,
      tone,
      priority_channels: channels,
      publish_timing: publishTiming,
      scheduled_for: scheduledFor,
      attachment_file_name: attachmentFile?.name,
      attachment_size_bytes: attachmentFile?.size,
    };

    const clientErrors = validateNewRequest(input);
    if (channels.length === 0) {
      clientErrors.push({ field: "priority_channels", message: "Pick at least one channel." });
    }
    if (clientErrors.length > 0) {
      setErrors(clientErrors);
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/webhooks/content-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...input, reviewer_ids: reviewerIds }),
      });
      const body = await res.json();
      if (!res.ok || !body.ok) {
        setErrors(body.errors ?? []);
        if (!body.errors) {
          setSubmitError("Something went wrong submitting the request. Try again.");
        }
        return;
      }
      router.push(`/requests/${body.request_id}`);
    } catch {
      setSubmitError("Couldn't reach the server. Check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5 max-w-2xl">
      {submitError && (
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">
          {submitError}
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Idea / topic <span className="text-red-500">*</span>
        </label>
        <textarea
          value={ideaOrTopic}
          onChange={(e) => setIdeaOrTopic(e.target.value)}
          rows={3}
          className="w-full rounded-md border border-slate-300 text-sm p-2"
          placeholder="Describe the content idea in a sentence or two — not just a link or a keyword."
        />
        {errorFor("idea_or_topic") && (
          <p className="mt-1 text-xs text-red-600">{errorFor("idea_or_topic")}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Target audience <span className="text-red-500">*</span>
        </label>
        <input
          value={targetAudience}
          onChange={(e) => setTargetAudience(e.target.value)}
          className="w-full rounded-md border border-slate-300 text-sm p-2"
          placeholder="e.g. Early-career product managers"
        />
        {errorFor("target_audience") && (
          <p className="mt-1 text-xs text-red-600">{errorFor("target_audience")}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Reference URL <span className="text-slate-400 font-normal">(optional)</span>
        </label>
        <input
          value={sourceUrl}
          onChange={(e) => setSourceUrl(e.target.value)}
          className="w-full rounded-md border border-slate-300 text-sm p-2"
          placeholder="https://..."
        />
        {errorFor("source_url") && (
          <p className="mt-1 text-xs text-red-600">{errorFor("source_url")}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Supporting material <span className="text-slate-400 font-normal">(optional)</span>
        </label>
        <input
          type="file"
          accept=".txt,.pdf,.xlsx,.csv,.docx"
          onChange={(e) => setAttachmentFile(e.target.files?.[0] ?? null)}
          className="w-full text-sm"
        />
        <p className="mt-1 text-xs text-slate-400">
          .txt, .pdf, .xlsx, .csv, or .docx — up to 20MB. Corrupt files are caught during
          research and flagged, not silently dropped.
        </p>
        {errorFor("attachment") && (
          <p className="mt-1 text-xs text-red-600">{errorFor("attachment")}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Tone</label>
        <select
          value={tone}
          onChange={(e) => setTone(e.target.value)}
          className="w-full rounded-md border border-slate-300 text-sm p-2"
        >
          <option value="professional">Professional</option>
          <option value="conversational">Conversational</option>
          <option value="authoritative">Authoritative</option>
          <option value="playful">Playful</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Channels <span className="text-red-500">*</span>
        </label>
        <div className="flex gap-4">
          {CHANNELS.map((c) => (
            <label key={c.value} className="flex items-center gap-1.5 text-sm text-slate-600">
              <input
                type="checkbox"
                checked={channels.includes(c.value)}
                onChange={() => toggleChannel(c.value)}
              />
              {c.label}
            </label>
          ))}
        </div>
        {errorFor("priority_channels") && (
          <p className="mt-1 text-xs text-red-600">{errorFor("priority_channels")}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Publishing</label>
        <div className="flex gap-4 mb-2">
          <label className="flex items-center gap-1.5 text-sm text-slate-600">
            <input
              type="radio"
              checked={publishTiming === "immediately"}
              onChange={() => setPublishTiming("immediately")}
            />
            Publish immediately after approval
          </label>
          <label className="flex items-center gap-1.5 text-sm text-slate-600">
            <input
              type="radio"
              checked={publishTiming === "scheduled"}
              onChange={() => setPublishTiming("scheduled")}
            />
            Schedule
          </label>
        </div>
        {publishTiming === "scheduled" && (
          <div>
            <input
              type="datetime-local"
              value={scheduledFor}
              onChange={(e) => setScheduledFor(e.target.value)}
              className="rounded-md border border-slate-300 text-sm p-2"
            />
            <p className="mt-1 text-xs text-slate-400">Past dates and times can&apos;t be selected.</p>
            {errorFor("scheduled_for") && (
              <p className="mt-1 text-xs text-red-600">{errorFor("scheduled_for")}</p>
            )}
          </div>
        )}
      </div>

      {reviewerCandidates.length > 0 && (
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Reviewers <span className="text-slate-400 font-normal">(optional)</span>
          </label>
          <div className="flex flex-wrap gap-3">
            {reviewerCandidates.map((p) => (
              <label key={p.id} className="flex items-center gap-1.5 text-sm text-slate-600">
                <input
                  type="checkbox"
                  checked={reviewerIds.includes(p.id)}
                  onChange={() => toggleReviewer(p.id)}
                />
                {p.name}
              </label>
            ))}
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Any assigned reviewer can approve, reject, or request changes — the first decision
            recorded wins (DESIGN.md §7).
          </p>
        </div>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="text-sm font-medium bg-accent-600 text-white px-4 py-2 rounded-md hover:bg-accent-700 disabled:opacity-50"
      >
        {submitting ? "Submitting..." : "Submit request"}
      </button>
    </form>
  );
}
