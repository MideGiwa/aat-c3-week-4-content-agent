import type { SourceRef } from "@/lib/types";

export default function SourceList({ sources }: { sources: SourceRef[] }) {
  const selected = sources.filter((s) => s.selected);
  const rejected = sources.filter((s) => !s.selected);

  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-2">
        Sources ({selected.length} used{rejected.length > 0 ? `, ${rejected.length} not used` : ""})
      </h3>
      <ul className="space-y-2">
        {selected.map((s) => (
          <li key={s.id} className="text-xs">
            <a
              href={s.url}
              target="_blank"
              rel="noreferrer"
              className="text-accent-700 hover:underline font-medium"
            >
              {s.title}
            </a>
            {s.relevance_note && <p className="text-slate-400 mt-0.5">{s.relevance_note}</p>}
          </li>
        ))}
      </ul>

      {rejected.length > 0 && (
        <details className="mt-3">
          <summary className="text-xs text-slate-400 cursor-pointer">
            Considered but not used ({rejected.length})
          </summary>
          <ul className="mt-2 space-y-2">
            {rejected.map((s) => (
              <li key={s.id} className="text-xs text-slate-400">
                {s.title}
                {s.relevance_note && <span> — {s.relevance_note}</span>}
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
}
