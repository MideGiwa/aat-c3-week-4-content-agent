"use client";

// Client wrapper tying VersionHistory's interactive version-switcher to the
// otherwise-static DraftViewer/EvaluationPanel below it, and deciding which
// draft ReviewActions applies to. Review actions always apply to the LATEST
// draft version, never whichever one happens to be selected for viewing —
// otherwise a reviewer browsing an old version could accidentally "approve"
// a draft that's since been superseded. Older versions are read-only.

import { useState } from "react";
import type { Draft, Evaluation, ReviewDecision, SourceRef } from "@/lib/types";
import VersionHistory from "./VersionHistory";
import DraftViewer from "./DraftViewer";
import EvaluationPanel from "./EvaluationPanel";
import ReviewActions from "./ReviewActions";

export default function DraftReviewPanel({
  requestId,
  drafts,
  evaluations,
  sources,
  latestDecision,
}: {
  requestId: string;
  drafts: Draft[];
  evaluations: Evaluation[];
  sources: SourceRef[];
  latestDecision: ReviewDecision | null;
}) {
  const latestDraft = drafts[drafts.length - 1];
  const [selectedDraftId, setSelectedDraftId] = useState(latestDraft?.id ?? "");

  if (!latestDraft) {
    return (
      <div className="text-sm text-slate-400">
        No draft has been generated for this request yet.
      </div>
    );
  }

  const selectedDraft = drafts.find((d) => d.id === selectedDraftId) ?? latestDraft;
  const selectedEvaluation = evaluations
    .filter((e) => e.draft_id === selectedDraftId)
    .at(-1);
  const isLatest = selectedDraft.id === latestDraft.id;

  return (
    <div className="space-y-4">
      {drafts.length > 1 && (
        <VersionHistory
          drafts={drafts}
          evaluations={evaluations}
          selectedDraftId={selectedDraftId}
          onSelect={setSelectedDraftId}
        />
      )}

      <div className="rounded-lg border border-slate-200 bg-white p-4">
        <DraftViewer draft={selectedDraft} sources={sources} />
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-4">
        <EvaluationPanel evaluation={selectedEvaluation} />
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-4">
        <h3 className="text-sm font-semibold text-slate-700 mb-2">Review decision</h3>
        {isLatest ? (
          <ReviewActions
            requestId={requestId}
            draftId={latestDraft.id}
            existingDecision={latestDecision}
          />
        ) : (
          <p className="text-xs text-slate-400">
            Viewing v{selectedDraft.version} — review actions apply to the latest version
            (v{latestDraft.version}) only. Switch to it above to decide.
          </p>
        )}
      </div>
    </div>
  );
}
