import type { Draft, SourceRef } from "@/lib/types";

export default function DraftViewer({ draft, sources }: { draft: Draft; sources: SourceRef[] }) {
  const sourceById = new Map(sources.map((s) => [s.id, s]));

  return (
    <article className="prose-sm max-w-none">
      <h1 className="text-2xl font-semibold text-slate-900 mb-1">{draft.title}</h1>
      <p className="text-xs text-slate-400 mb-6">
        Version {draft.version} · generated {new Date(draft.created_at).toLocaleString()}
      </p>

      {draft.sections.map((section, idx) => (
        <section key={idx} className="mb-6">
          <h2 className="text-lg font-semibold text-slate-800 mb-2">{section.heading}</h2>
          <p className="text-sm leading-relaxed text-slate-700 whitespace-pre-line">{section.body}</p>
          {section.cited_source_ids.length > 0 ? (
            <p className="mt-2 text-xs text-slate-400">
              Sources:{" "}
              {section.cited_source_ids
                .map((id) => sourceById.get(id)?.title ?? id)
                .join(", ")}
            </p>
          ) : (
            <p className="mt-2 text-xs text-red-500">⚠ No cited source for this section.</p>
          )}
        </section>
      ))}
    </article>
  );
}
